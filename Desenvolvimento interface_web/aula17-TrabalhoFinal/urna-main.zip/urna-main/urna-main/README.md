# urna
Simulador da urna eletrônica feita com HTML, CSS e Javascript.
